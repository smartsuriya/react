import React from 'react';

class NotFound extends React.Component {
  render() {
    return (
      <h2>Not Found!111!!</h2>
    )
  }
}

export default NotFound;
